package utils

type Map map[string]interface{}
